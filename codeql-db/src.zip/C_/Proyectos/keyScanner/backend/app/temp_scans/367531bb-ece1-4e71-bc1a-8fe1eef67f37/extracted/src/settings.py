AWS_SECRET = "AKIA1234567890EXAMPLE"
DB_URL = "postgres://root:SuperSecret123@db:5432/app"