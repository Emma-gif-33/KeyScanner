"""create_initial_schema

Revision ID: d0862e201ff5
Revises: 
Create Date: 2026-11-05 23:51:16.901424

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = 'd0862e201ff5'
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.create_table('users',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('email', sa.String(length=255), nullable=False),
    sa.Column('hashed_password', sa.String(length=255), nullable=False),
    sa.Column('full_name', sa.String(length=255), nullable=True),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_users_email'), 'users', ['email'], unique=True)
    op.create_index(op.f('ix_users_id'), 'users', ['id'], unique=False)
    op.create_table('scans',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('user_id', sa.UUID(), nullable=False),
    sa.Column('project_name', sa.String(length=255), nullable=False),
    sa.Column('source_filename', sa.String(length=255), nullable=False),
    sa.Column('file_hash_sha256', sa.String(length=64), nullable=False),
    sa.Column('status', sa.String(length=32), nullable=False),
    sa.Column('total_secrets', sa.Integer(), nullable=False),
    sa.Column('total_vulnerabilities', sa.Integer(), nullable=False),
    sa.Column('risk_level', sa.String(length=16), nullable=False),
    sa.Column('summary_metrics', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
    sa.Column('error_message', sa.Text(), nullable=True),
    sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_scans_file_hash_sha256'), 'scans', ['file_hash_sha256'], unique=False)
    op.create_index(op.f('ix_scans_id'), 'scans', ['id'], unique=False)
    op.create_index(op.f('ix_scans_project_name'), 'scans', ['project_name'], unique=False)
    op.create_index(op.f('ix_scans_status'), 'scans', ['status'], unique=False)
    op.create_index(op.f('ix_scans_user_id'), 'scans', ['user_id'], unique=False)
    op.create_table('dependency_findings',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('scan_id', sa.UUID(), nullable=False),
    sa.Column('package_name', sa.String(length=255), nullable=False),
    sa.Column('installed_version', sa.String(length=64), nullable=False),
    sa.Column('ecosystem', sa.String(length=32), nullable=False),
    sa.Column('manifest_file', sa.String(length=255), nullable=False),
    sa.Column('osv_id', sa.String(length=64), nullable=False),
    sa.Column('severity', sa.String(length=16), nullable=False),
    sa.Column('fixed_version', sa.String(length=64), nullable=True),
    sa.Column('summary', sa.Text(), nullable=True),
    sa.Column('advisory_url', sa.Text(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['scan_id'], ['scans.id'], ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_dependency_findings_ecosystem'), 'dependency_findings', ['ecosystem'], unique=False)
    op.create_index(op.f('ix_dependency_findings_id'), 'dependency_findings', ['id'], unique=False)
    op.create_index(op.f('ix_dependency_findings_osv_id'), 'dependency_findings', ['osv_id'], unique=False)
    op.create_index(op.f('ix_dependency_findings_package_name'), 'dependency_findings', ['package_name'], unique=False)
    op.create_index(op.f('ix_dependency_findings_scan_id'), 'dependency_findings', ['scan_id'], unique=False)
    op.create_index(op.f('ix_dependency_findings_severity'), 'dependency_findings', ['severity'], unique=False)
    op.create_table('secret_findings',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('scan_id', sa.UUID(), nullable=False),
    sa.Column('rule_id', sa.String(length=64), nullable=False),
    sa.Column('secret_type', sa.String(length=128), nullable=False),
    sa.Column('file_path', sa.Text(), nullable=False),
    sa.Column('line_number', sa.Integer(), nullable=False),
    sa.Column('masked_snippet', sa.Text(), nullable=False),
    sa.Column('entropy_score', sa.Float(), nullable=True),
    sa.Column('severity', sa.String(length=16), nullable=False),
    sa.Column('remediation_tip', sa.Text(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['scan_id'], ['scans.id'], ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_secret_findings_id'), 'secret_findings', ['id'], unique=False)
    op.create_index(op.f('ix_secret_findings_rule_id'), 'secret_findings', ['rule_id'], unique=False)
    op.create_index(op.f('ix_secret_findings_scan_id'), 'secret_findings', ['scan_id'], unique=False)
    op.create_index(op.f('ix_secret_findings_severity'), 'secret_findings', ['severity'], unique=False)


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(op.f('ix_secret_findings_severity'), table_name='secret_findings')
    op.drop_index(op.f('ix_secret_findings_scan_id'), table_name='secret_findings')
    op.drop_index(op.f('ix_secret_findings_rule_id'), table_name='secret_findings')
    op.drop_index(op.f('ix_secret_findings_id'), table_name='secret_findings')
    op.drop_table('secret_findings')
    op.drop_index(op.f('ix_dependency_findings_severity'), table_name='dependency_findings')
    op.drop_index(op.f('ix_dependency_findings_scan_id'), table_name='dependency_findings')
    op.drop_index(op.f('ix_dependency_findings_package_name'), table_name='dependency_findings')
    op.drop_index(op.f('ix_dependency_findings_osv_id'), table_name='dependency_findings')
    op.drop_index(op.f('ix_dependency_findings_id'), table_name='dependency_findings')
    op.drop_index(op.f('ix_dependency_findings_ecosystem'), table_name='dependency_findings')
    op.drop_table('dependency_findings')
    op.drop_index(op.f('ix_scans_user_id'), table_name='scans')
    op.drop_index(op.f('ix_scans_status'), table_name='scans')
    op.drop_index(op.f('ix_scans_project_name'), table_name='scans')
    op.drop_index(op.f('ix_scans_id'), table_name='scans')
    op.drop_index(op.f('ix_scans_file_hash_sha256'), table_name='scans')
    op.drop_table('scans')
    op.drop_index(op.f('ix_users_id'), table_name='users')
    op.drop_index(op.f('ix_users_email'), table_name='users')
    op.drop_table('users')
