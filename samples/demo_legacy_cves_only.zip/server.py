import os
from flask import Flask

app = Flask(__name__)
# Good practice: reading secrets strictly from environment variables (0 secrets exposed)
DB_URI = os.environ.get("PROD_DATABASE_URI")
JWT_SECRET = os.environ.get("PROD_JWT_SECRET")

@app.route("/status")
def status():
    return {"ok": True}
