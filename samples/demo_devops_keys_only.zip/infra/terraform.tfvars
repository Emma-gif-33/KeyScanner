# Cloud Provisioning Variables
aws_access_key = "AKIA5566778899ABCDEF"
aws_secret_key = "AbCdEfGhIjKlMnOpQrStUvWxYz0123456789/+Ab"
gcp_api_key    = "AIzaSyB9876543210zyxwvutsrqponmlkjihgfe"
