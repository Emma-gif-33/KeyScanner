# Fullstack Backend Settings with exposed credentials
MONGO_Cluster_URI = "mongodb+srv://admin_root:M0ng0Pr0dP4ssw0rd99!@cluster0.mongodb.net/production"
aws_secret_access_key = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
SLACK_BOT_TOKEN = "xoxb-123456789012-1234567890123-AbCdEfGhIjKlMnOpQrStUvWx"
