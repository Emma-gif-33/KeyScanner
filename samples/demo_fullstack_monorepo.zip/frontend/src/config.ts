export const STRIPE_TEST_PUBLIC = "pk_test_51H8zX2AbcdefghijklmnopQRST1234";
export const INTERNAL_AUTH_TOKEN = "auth_token_9876543210abcdef12345678";
